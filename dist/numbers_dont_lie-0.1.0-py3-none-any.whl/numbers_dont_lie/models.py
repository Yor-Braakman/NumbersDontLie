from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class ColumnStats:
    """Statistics for a single column."""

    name: str
    data_type: str
    nullable: bool
    distinct_count: Optional[int] = None
    min_value: Optional[Any] = None
    max_value: Optional[Any] = None
    null_count: int = 0
    avg_length: Optional[float] = None
    max_length: Optional[int] = None

    @property
    def null_ratio(self) -> float:
        if self.distinct_count is None:
            return 0.0
        total = self.distinct_count + self.null_count
        return self.null_count / total if total > 0 else 0.0

    @property
    def is_categorical(self) -> bool:
        if self.data_type not in ("string", "varchar", "char", "text"):
            return False
        if self.distinct_count is None:
            return False
        total_count = self.distinct_count + self.null_count
        return total_count > 0 and (self.distinct_count / total_count) < 0.05


@dataclass
class TableStats:
    """Complete statistics for a table."""

    database_name: str
    schema_name: str
    table_name: str
    num_records: int
    columns: List[ColumnStats] = field(default_factory=list)

    @property
    def full_name(self) -> str:
        parts = [p for p in [self.database_name, self.schema_name, self.table_name] if p]
        return ".".join(parts)

    def get_column(self, name: str) -> Optional[ColumnStats]:
        for col in self.columns:
            if col.name == name:
                return col
        return None
