"""SQLite statistics reader and writer."""

import sqlite3
from pathlib import Path
from typing import List, Optional, Tuple

import pandas as pd

from numbers_dont_lie.models import ColumnStats, TableStats
from numbers_dont_lie.readers import BaseStatsReader, BaseWriter


class SQLiteStatsReader(BaseStatsReader):
    """Read table statistics from SQLite using pragma and sqlite_stat tables."""

    def __init__(self, database_path: str):
        self.database_path = database_path
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        if not Path(self.database_path).exists():
            raise FileNotFoundError(f"Database not found: {self.database_path}")
        self._conn = sqlite3.connect(self.database_path)
        self._conn.row_factory = sqlite3.Row

    def disconnect(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def list_tables(self, schema: Optional[str] = None) -> List[Tuple[str, str, str]]:
        cur = self._conn.cursor()
        cur.execute("""
            SELECT name FROM sqlite_master
            WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
            ORDER BY name
        """)
        db_name = Path(self.database_path).stem
        return [(db_name, "main", row[0]) for row in cur.fetchall()]

    def read_table_stats(self, schema: str, table: str) -> TableStats:
        row_count = self._get_row_count(table)
        columns = self._get_column_stats(table, row_count)

        db_name = Path(self.database_path).stem
        return TableStats(
            database_name=db_name,
            schema_name=schema,
            table_name=table,
            num_records=row_count,
            columns=columns,
        )

    def _get_row_count(self, table: str) -> int:
        """Get row count - try stat tables first, fall back to COUNT."""
        cur = self._conn.cursor()

        # Try sqlite_stat1 (populated by ANALYZE)
        try:
            cur.execute(
                "SELECT stat FROM sqlite_stat1 WHERE tbl = ? AND idx IS NULL",
                (table,),
            )
            row = cur.fetchone()
            if row:
                # stat column format: "nrows ..."
                return int(str(row[0]).split()[0])
        except sqlite3.OperationalError:
            pass

        # Fall back to COUNT (SQLite is fast for this)
        cur.execute(f'SELECT COUNT(*) FROM "{table}"')  # noqa: S608
        return cur.fetchone()[0]

    def _get_column_stats(self, table: str, row_count: int) -> List[ColumnStats]:
        cur = self._conn.cursor()
        cur.execute(f'PRAGMA table_info("{table}")')
        pragma_rows = cur.fetchall()

        columns = []
        for row in pragma_rows:
            col_name = row[1]
            data_type = row[2] or "text"
            nullable = row[3] == 0  # notnull column: 0 means nullable

            # Get basic stats via aggregate queries on metadata
            stats = self._get_single_column_stats(table, col_name, row_count)

            columns.append(ColumnStats(
                name=col_name,
                data_type=data_type.lower(),
                nullable=nullable,
                distinct_count=stats.get("distinct_count"),
                min_value=stats.get("min_value"),
                max_value=stats.get("max_value"),
                null_count=stats.get("null_count", 0),
                avg_length=stats.get("avg_length"),
                max_length=stats.get("max_length"),
            ))

        return columns

    def _get_single_column_stats(self, table: str, column: str, row_count: int) -> dict:
        """Get stats for a single column using aggregate queries."""
        cur = self._conn.cursor()

        # Use a single aggregate query for efficiency
        query = f"""
            SELECT
                COUNT(DISTINCT "{column}") as distinct_count,
                MIN("{column}") as min_val,
                MAX("{column}") as max_val,
                SUM(CASE WHEN "{column}" IS NULL THEN 1 ELSE 0 END) as null_count,
                AVG(LENGTH("{column}")) as avg_length,
                MAX(LENGTH("{column}")) as max_length
            FROM "{table}"
        """  # noqa: S608
        cur.execute(query)
        row = cur.fetchone()

        return {
            "distinct_count": row[0],
            "min_value": row[1],
            "max_value": row[2],
            "null_count": row[3] or 0,
            "avg_length": row[4],
            "max_length": row[5],
        }


class SQLiteWriter(BaseWriter):
    """Write synthetic data to SQLite."""

    def __init__(self, database_path: str):
        self.database_path = database_path
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        self._conn = sqlite3.connect(self.database_path)

    def disconnect(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def write_table(self, df: pd.DataFrame, schema: str, table: str, if_exists: str = "replace") -> int:
        df.to_sql(table, self._conn, if_exists=if_exists, index=False)
        return len(df)
