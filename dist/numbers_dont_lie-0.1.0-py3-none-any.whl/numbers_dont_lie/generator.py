"""Synthetic data generator using pandas/numpy (no Spark dependency)."""

import uuid
from datetime import datetime, timedelta
from typing import List

import numpy as np
import pandas as pd

from numbers_dont_lie.models import ColumnStats, TableStats


class SyntheticDataGenerator:
    """Generate synthetic data from table statistics using pandas."""

    def __init__(self, scale_factor: float = 1.0, seed: int | None = None):
        self.scale_factor = scale_factor
        self.rng = np.random.default_rng(seed)

    def generate(self, table_stats: TableStats) -> pd.DataFrame:
        """Generate a synthetic DataFrame based on table statistics."""
        target_rows = int(table_stats.num_records * self.scale_factor)
        if target_rows == 0:
            target_rows = 100  # minimum fallback

        data = {}
        for col_stats in table_stats.columns:
            data[col_stats.name] = self._generate_column(col_stats, target_rows)

        return pd.DataFrame(data)

    def _generate_column(self, col_stats: ColumnStats, num_rows: int) -> pd.Series:
        dtype = col_stats.data_type.lower()

        if any(t in dtype for t in ("int", "serial", "bigint", "smallint", "tinyint")):
            values = self._generate_integer(col_stats, num_rows)
        elif any(t in dtype for t in ("double", "float", "real", "numeric", "decimal")):
            values = self._generate_numeric(col_stats, num_rows)
        elif any(t in dtype for t in ("char", "varchar", "text", "string", "clob")):
            values = self._generate_string(col_stats, num_rows)
        elif "date" in dtype and "time" not in dtype:
            values = self._generate_date(col_stats, num_rows)
        elif "timestamp" in dtype or "datetime" in dtype:
            values = self._generate_timestamp(col_stats, num_rows)
        elif "bool" in dtype:
            values = self._generate_boolean(num_rows)
        elif "blob" in dtype or "binary" in dtype or "bytea" in dtype:
            values = self._generate_binary(col_stats, num_rows)
        elif "uuid" in dtype or "uniqueidentifier" in dtype:
            values = self._generate_uuid(num_rows)
        else:
            values = self._generate_string(col_stats, num_rows)

        series = pd.Series(values, name=col_stats.name)

        # Inject nulls
        if col_stats.nullable and col_stats.null_ratio > 0:
            mask = self.rng.random(num_rows) < col_stats.null_ratio
            series = series.where(~mask, other=None)

        return series

    def _generate_integer(self, col_stats: ColumnStats, n: int) -> np.ndarray:
        min_val = int(col_stats.min_value) if col_stats.min_value is not None else 0
        max_val = int(col_stats.max_value) if col_stats.max_value is not None else 1_000_000

        if col_stats.distinct_count and col_stats.distinct_count < 50:
            # Low cardinality - pick from discrete set
            categories = np.arange(min_val, min_val + col_stats.distinct_count)
            return self.rng.choice(categories, size=n)

        return self.rng.integers(min_val, max_val + 1, size=n)

    def _generate_numeric(self, col_stats: ColumnStats, n: int) -> np.ndarray:
        min_val = float(col_stats.min_value) if col_stats.min_value is not None else 0.0
        max_val = float(col_stats.max_value) if col_stats.max_value is not None else 1_000_000.0
        return self.rng.uniform(min_val, max_val, size=n)

    def _generate_string(self, col_stats: ColumnStats, n: int) -> List[str]:
        if col_stats.is_categorical and col_stats.distinct_count:
            categories = [f"Category_{i}" for i in range(col_stats.distinct_count)]
            indices = self.rng.integers(0, len(categories), size=n)
            return [categories[i] for i in indices]

        target_length = int(col_stats.avg_length) if col_stats.avg_length else 12
        target_length = max(4, min(target_length, 200))

        # Check if it looks like an ID/GUID column
        name_lower = col_stats.name.lower()
        if any(k in name_lower for k in ("guid", "uuid", "id")):
            return [str(uuid.uuid4()) for _ in range(n)]

        chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return [
            "".join(self.rng.choice(list(chars), size=target_length))
            for _ in range(n)
        ]

    def _generate_date(self, col_stats: ColumnStats, n: int) -> List:
        try:
            min_date = pd.to_datetime(col_stats.min_value) if col_stats.min_value else datetime(2020, 1, 1)
            max_date = pd.to_datetime(col_stats.max_value) if col_stats.max_value else datetime.now()
        except (ValueError, TypeError):
            min_date = datetime(2020, 1, 1)
            max_date = datetime.now()

        days_range = (max_date - min_date).days
        if days_range <= 0:
            days_range = 365 * 5

        random_days = self.rng.integers(0, days_range, size=n)
        return [min_date + timedelta(days=int(d)) for d in random_days]

    def _generate_timestamp(self, col_stats: ColumnStats, n: int) -> List:
        try:
            min_ts = pd.to_datetime(col_stats.min_value) if col_stats.min_value else datetime(2020, 1, 1)
            max_ts = pd.to_datetime(col_stats.max_value) if col_stats.max_value else datetime.now()
        except (ValueError, TypeError):
            min_ts = datetime(2020, 1, 1)
            max_ts = datetime.now()

        seconds_range = int((max_ts - min_ts).total_seconds())
        if seconds_range <= 0:
            seconds_range = 365 * 5 * 86400

        random_seconds = self.rng.integers(0, seconds_range, size=n)
        return [min_ts + timedelta(seconds=int(s)) for s in random_seconds]

    def _generate_boolean(self, n: int) -> np.ndarray:
        return self.rng.choice([True, False], size=n)

    def _generate_binary(self, col_stats: ColumnStats, n: int) -> List[bytes]:
        length = int(col_stats.avg_length) if col_stats.avg_length else 16
        return [self.rng.bytes(length) for _ in range(n)]

    def _generate_uuid(self, n: int) -> List[str]:
        return [str(uuid.uuid4()) for _ in range(n)]
